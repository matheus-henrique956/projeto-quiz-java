public class Questao {
    private String enunciado;
    private String[] alternativas;
    private int respostaCorreta; // Índice da alternativa correta (de 1 a 4)


    public Questao(String enunciado, String[] alternativas, int respostaCorreta) {
        this.enunciado = enunciado;
        this.alternativas = alternativas;
        this.respostaCorreta = respostaCorreta;
    }

    // Método para exibir a questão e as alternativas no console
    public void exibirQuestao(int numeroQuestao) {
        System.out.println("\nQuestão " + numeroQuestao + ": " + enunciado);
        for (int i = 0; i < alternativas.length; i++) {
            System.out.println("  (" + (i + 1) + ") " + alternativas[i]);
        }
    }

    // Método para verificar se a resposta do usuário está correta
    public boolean validarResposta(int respostaUsuario) {
        return respostaUsuario == respostaCorreta;
    }
}
