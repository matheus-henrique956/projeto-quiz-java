import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // ==========================================
        // CABEÇALHO DO SISTEMA
        // ==========================================
        System.out.println("==================================================");
        System.out.println("          SISTEMA DE QUIZ - PROGRAMAÇÃO II        ");
        System.out.println("==================================================");
        System.out.println("Nome do Aluno: Seu Nome Completo");
        System.out.println("Nome do Professor: Nome do Professor");
        System.out.println("Faculdade: Nome da Faculdade");
        System.out.println("Curso: Engenharia de Software / Segurança da Informação");
        System.out.println("==================================================\n");

        // Criando a ArrayList para armazenar as 15 questões
        ArrayList<Questao> listaQuestoes = new ArrayList<>();

        // Adicionando as 15 questões (Tema: Tecnologia e Programação)
        listaQuestoes.add(new Questao(
                "Qual linguagem é amplamente utilizada para desenvolvimento Android nativo e aplicações corporativas?",
                new String[]{"Python", "Java", "HTML", "Ruby"}, 2
        ));

        listaQuestoes.add(new Questao(
                "Qual estrutura de dados utiliza o princípio LIFO (Last In, First Out)?",
                new String[]{"Fila (Queue)", "Pilha (Stack)", "Lista Encadeada", "Árvore Binária"}, 2
        ));

        listaQuestoes.add(new Questao(
                "O que significa a sigla POO em desenvolvimento de software?",
                new String[]{"Processo Orientado a Objetos", "Programa Operacional Otimizado", "Programação Orientada a Objetos", "Padrão Oficial de Operação"}, 3
        ));

        listaQuestoes.add(new Questao(
                "Qual palavra-chave em Java é utilizada para herança de classes?",
                new String[]{"implements", "extends", "inherits", "super"}, 2
        ));

        listaQuestoes.add(new Questao(
                "Em segurança da informação, o que representa a letra 'C' na Tríade CIA?",
                new String[]{"Confidencialidade", "Confiabilidade", "Controle", "Conexão"}, 1
        ));

        listaQuestoes.add(new Questao(
                "Qual o operador lógico utilizado para representar 'E' (AND) em Java?",
                new String[]{"||", "&&", "!", "=="}, 2
        ));

        listaQuestoes.add(new Questao(
                "Qual componente do Java é responsável por executar o bytecode?",
                new String[]{"JDK", "JRE", "JVM", "IDE"}, 3
        ));

        listaQuestoes.add(new Questao(
                "Qual protocolo é utilizado para navegação web segura (criptografada)?",
                new String[]{"HTTP", "FTP", "HTTPS", "SMTP"}, 3
        ));

        listaQuestoes.add(new Questao(
                "Qual estrutura de repetição é ideal quando sabemos exatamente o número de vezes que o bloco deve rodar?",
                new String[]{"while", "do-while", "for", "if-else"}, 3
        ));

        listaQuestoes.add(new Questao(
                "O que é um ataque de 'Phishing'?",
                new String[]{"Inundação de tráfego em servidores", "Engenharia social para roubo de dados", "Injeção de código malicioso em banco de dados", "Desativação de firewalls"}, 2
        ));

        listaQuestoes.add(new Questao(
                "Qual método é o ponto de entrada principal para a execução de um programa Java?",
                new String[]{"start()", "init()", "main()", "run()"}, 3
        ));

        listaQuestoes.add(new Questao(
                "Qual das opções abaixo é uma Collection do Java que não permite elementos duplicados?",
                new String[]{"ArrayList", "LinkedList", "HashSet", "Vector"}, 3
        ));

        listaQuestoes.add(new Questao(
                "O que significa a sigla SQL?",
                new String[]{"Simple Query Language", "Structured Query Language", "System Quality Link", "Secure Quick Logic"}, 2
        ));

        listaQuestoes.add(new Questao(
                "Qual modificador de acesso em Java torna o membro visível apenas dentro da própria classe?",
                new String[]{"public", "protected", "private", "default"}, 3
        ));

        listaQuestoes.add(new Questao(
                "Qual ferramenta de controle de versão foi criada por Linus Torvalds?",
                new String[]{"SVN", "Git", "Mercurial", "CVS"}, 2
        ));

        // ==========================================
        // EXECUÇÃO DO QUIZ
        // ==========================================
        int acertos = 0;

        for (int i = 0; i < listaQuestoes.size(); i++) {
            Questao q = listaQuestoes.get(i);
            q.exibirQuestao(i + 1);

            System.out.print("Digite o número da sua resposta (1 a 4): ");
            int respostaUsuario = -1;

            // Validação simples para garantir que o usuário digite um número válido
            while (true) {
                if (scanner.hasNextInt()) {
                    respostaUsuario = scanner.nextInt();
                    if (respostaUsuario >= 1 && respostaUsuario <= 4) {
                        break;
                    }
                } else {
                    scanner.next(); // limpar entrada inválida
                }
                System.out.print("Opção inválida! Digite um número entre 1 e 4: ");
            }

            // Valida se acertou
            if (q.validarResposta(respostaUsuario)) {
                System.out.println("✅ Resposta Correta!\n");
                acertos++;
            } else {
                System.out.println("❌ Resposta Incorreta!\n");
            }
        }

        // ==========================================
        // RESULTADOS FINAIS
        // ==========================================
        double porcentagem = ((double) acertos / listaQuestoes.size()) * 100;

        System.out.println("==================================================");
        System.out.println("                   FIM DO QUIZ                    ");
        System.out.println("==================================================");
        System.out.println("Total de questões: " + listaQuestoes.size());
        System.out.println("Quantidade de acertos: " + acertos);
        System.out.printf("Porcentagem de acertos: %.2f%%\n", porcentagem);
        System.out.println("\n🎉 Muito obrigado por participar do Quiz! Volte sempre!");
        System.out.println("==================================================");

        scanner.close();
    }
}